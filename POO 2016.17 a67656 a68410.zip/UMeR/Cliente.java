
public class Cliente extends Actor
{
   
    private Coords posicao;//nao sei se precisamos disto
    //lista de viagens efetuadas. talvez seja melhor criar a class viagem
}

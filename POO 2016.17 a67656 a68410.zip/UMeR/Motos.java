
/**
 * Escreva a descrição da classe motos aqui.
 * 
 * @author (seu nome) 
 * @version (número de versão ou data)
 */
public class Motos extends Veiculo
{
    
}

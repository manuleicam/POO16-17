
public class Veiculo
{
    private int velMediaKM; //o que caralho é uma velocidade média por kilomtero, velocidade media ou uma lista de velocidades médias por cada km?
    private int precoPorKM;
    private int fiabilidade;
    private Coords posicao;
}

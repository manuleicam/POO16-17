
/**
 * Write a description of class Viagem here.
 *
 * @author My name
 * @version 1
 */
public class Viagem
{
	private int id;
    private Coords inicio;
    private Coords fim;
    private int distancia;
    private int preco;
    private Motorista condutor;
    private Veiculo veiculo;
    //private Date/hora
}

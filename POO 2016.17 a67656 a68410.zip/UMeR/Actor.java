 

 public class Actor 
 {
 	private String email;
    private String nome;
    private String password;
    private String morada;
    private String dataNasc; //nice try existe date
}
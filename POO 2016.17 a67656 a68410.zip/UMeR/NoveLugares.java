
public class NoveLugares extends Veiculo
{
    
}
